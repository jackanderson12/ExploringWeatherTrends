SELECT *
FROM global_data
ORDER BY global_data.year;
