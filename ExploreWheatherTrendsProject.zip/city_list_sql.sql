SELECT *
FROM city_list
WHERE city_list.country = 'United States'
ORDER BY city_list.city;
